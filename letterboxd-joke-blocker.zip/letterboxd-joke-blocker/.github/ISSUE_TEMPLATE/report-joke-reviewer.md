---
name: Report a joke reviewer
about: Flag a Letterboxd user whose reviews are jokes-only
title: "Report: "
labels: report
---

**Reported username:**

**Review URL:**

**Review excerpt (paste the review text):**

**Why this fits the definition** (a short review that consists only of a joke or jokes, with no actual commentary on the film):

**Have you checked this user's other reviews to confirm this isn't a one-off?**
